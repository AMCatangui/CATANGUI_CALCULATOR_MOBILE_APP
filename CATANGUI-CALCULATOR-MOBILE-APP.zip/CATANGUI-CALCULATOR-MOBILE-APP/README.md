Calculator Application

As a Flutter Programming Activity in Applications Development & Emerging Technologies subject, 
this project serves as a starting point for a Flutter application development.

For the requirements, 
- the application should allow the user to view the operations committed
- save operations into a file (for this program, txt file is used)
